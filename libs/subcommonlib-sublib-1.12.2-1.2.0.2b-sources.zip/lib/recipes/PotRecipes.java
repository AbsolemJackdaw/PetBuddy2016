package lib.recipes;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class PotRecipes {

	private static final PotRecipes INSTANCE = new PotRecipes();
	private Map<RecipeEntry, RecipeEntry> recipes = new HashMap<RecipeEntry, RecipeEntry>();

	private class RecipeEntry{

		int amount;
		Item item;
		int meta;

		public RecipeEntry(ItemStack stack) {
			amount = stack.func_190916_E();
			item = stack.func_77973_b();
			meta = stack.func_77960_j();
		}

		public ItemStack getStack(){
			return new ItemStack(item,amount,meta);
		}
		
		@Override
		public boolean equals(Object obj) {
			if(!(obj instanceof RecipeEntry))
				return false;
			
			if(!areEntriesEqual((RecipeEntry)obj, this))
				return false;
			
			return true;
		}
	}


	public static PotRecipes getInstance() {
		return INSTANCE;
	}

	public void addRecipe(ItemStack entry, ItemStack output){
		RecipeEntry reEntry = new RecipeEntry(entry);
		RecipeEntry reOutput = new RecipeEntry(output);
		recipes.put(reEntry, reOutput);
	}

	public ItemStack getCookingResult(ItemStack stack)
	{
		RecipeEntry entry = new RecipeEntry(stack);
		
		for (Entry<RecipeEntry, RecipeEntry> entry_lookup : recipes.entrySet())
		{
			RecipeEntry key = entry_lookup.getKey();
			if (areEntriesEqual(entry, key))
			{
				return entry_lookup.getValue().getStack().func_77946_l();
			}
		}
		return ItemStack.field_190927_a;
	}

	private boolean areEntriesEqual(RecipeEntry a, RecipeEntry b){

		if(a.meta == b.meta && a.item == b.item)
			return true;

		return false;
	}
}
