package lib.item;

import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.oredict.OreDictionary;

public class OreDictRegistry {

	public void addTo(){
		Item rawMeats[] = new Item[]{Items.field_151082_bd, Items.field_151147_al, Items.field_179558_bo, Items.field_179561_bm, Items.field_151076_bf};
		Item cookedMeats[] = new Item[]{Items.field_151083_be, Items.field_151157_am, Items.field_179559_bp, Items.field_179557_bn, Items.field_151077_bg};

		for(Item meat : rawMeats)
			if(meat != Items.field_151076_bf) 
				OreDictionary.registerOre("foodRedMeatRaw", meat);
		for(Item meat : cookedMeats)
			if(meat != Items.field_151077_bg)
				OreDictionary.registerOre("foodRedMeatCooked", meat);

		for(Item meat : rawMeats)
			OreDictionary.registerOre("foodMeatRaw", meat);
		for(Item meat : cookedMeats)
			OreDictionary.registerOre("foodMeatCooked", meat);
		
		//fish is meat too !
		OreDictionary.registerOre("foodMeatRaw", new ItemStack(Items.field_151115_aP,1,0));//cod
		OreDictionary.registerOre("foodMeatRaw", new ItemStack(Items.field_151115_aP,1,1));//salmon
		OreDictionary.registerOre("foodMeatCooked", new ItemStack(Items.field_179566_aV,1,0));//cod
		OreDictionary.registerOre("foodMeatCooked", new ItemStack(Items.field_179566_aV,1,1));//salmon

		//fish is also fish
		OreDictionary.registerOre("foodFishRaw", new ItemStack(Items.field_151115_aP,1,0));//cod
		OreDictionary.registerOre("foodFishRaw", new ItemStack(Items.field_151115_aP,1,1));//salmon

		OreDictionary.registerOre("foodFishCooked", new ItemStack(Items.field_179566_aV,1,0));//cod
		OreDictionary.registerOre("foodFishCooked", new ItemStack(Items.field_179566_aV,1,1));//salmon


		OreDictionary.registerOre("cropVegetable", Items.field_151174_bG);
		OreDictionary.registerOre("cropVegetable", Items.field_185164_cV);
		OreDictionary.registerOre("cropVegetable", Items.field_151172_bF);
		OreDictionary.registerOre("cropVegetable", Blocks.field_150423_aK);

		OreDictionary.registerOre("cropMushroom", Blocks.field_150338_P);
		OreDictionary.registerOre("cropMushroom", Blocks.field_150337_Q);

		OreDictionary.registerOre("dustSugar", Items.field_151102_aT);

		OreDictionary.registerOre("cropFruit", Items.field_151034_e);
		OreDictionary.registerOre("cropFruit", Items.field_151127_ba);

		OreDictionary.registerOre("itemFish", Items.field_151115_aP);
	}
}
