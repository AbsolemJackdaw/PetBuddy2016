package lib.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.EntityLivingBase;

/**Class made to prevent cluttering other classes with miles of code.*/
public class DrawEntityOnScreen {

	/**
	 * Draws an entity on the screen looking toward the cursor.
	 */
	public static void drawEntityOnScreen(int posX, int posY, int scale, float mouseX, float mouseY, EntityLivingBase ent, float rotation, float zLevel, boolean mirror)
	{
		GlStateManager.func_179142_g();
		GlStateManager.func_179094_E();
		GlStateManager.func_179109_b((float)posX, (float)posY, zLevel);
		GlStateManager.func_179152_a(mirror ?(float)(scale) :(float)(-scale), (float)scale, (float)scale);
		GlStateManager.func_179114_b(180.0f, 0.0F, 0.0F, 1.0F);
		float f = ent.field_70761_aq;
		float f1 = ent.field_70177_z;
		float f2 = ent.field_70125_A;
		float f3 = ent.field_70758_at;
		float f4 = ent.field_70759_as;
		GlStateManager.func_179114_b(rotation, 0.0F, 1.0F, 0.0F);
		RenderHelper.func_74519_b();
		GlStateManager.func_179114_b(-135.0F, 0.0F, 1.0F, 0.0F);
		GlStateManager.func_179114_b(-((float)Math.atan((double)(mouseY / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
		ent.field_70761_aq = (float)Math.atan((double)(mouseX / 40.0F)) * 20.0F;
		ent.field_70177_z = (float)Math.atan((double)(mouseX / 40.0F)) * 40.0F;
		ent.field_70125_A = -((float)Math.atan((double)(mouseY / 40.0F))) * 20.0F;
		ent.field_70759_as = ent.field_70177_z;
		ent.field_70758_at = ent.field_70177_z;
		GlStateManager.func_179109_b(0.0F, 0.0F, 0.0F);
		RenderManager rendermanager = Minecraft.func_71410_x().func_175598_ae();
		rendermanager.func_178631_a(180.0F);
		rendermanager.func_178633_a(false);
		rendermanager.func_188391_a(ent, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F, false);
		rendermanager.func_178633_a(true);
		ent.field_70761_aq = f;
		ent.field_70177_z = f1;
		ent.field_70125_A = f2;
		ent.field_70758_at = f3;
		ent.field_70759_as = f4;
		GlStateManager.func_179121_F();
		RenderHelper.func_74518_a();
		GlStateManager.func_179101_C();
		GlStateManager.func_179138_g(OpenGlHelper.field_77476_b);
		GlStateManager.func_179090_x();
		GlStateManager.func_179138_g(OpenGlHelper.field_77478_a);
	}

	public static void drawEntityOnScreen(int posX, int posY, int scale, float mouseX, float mouseY, EntityLivingBase ent){
		drawEntityOnScreen(posX, posY, scale, mouseX, mouseY, ent, 135.0F, 50.0F, false);
	}
}
