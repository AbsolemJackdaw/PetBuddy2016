package lib.util;

import java.util.List;

import com.google.common.base.Predicates;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EntitySelectors;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/**
 *
 * @author Richard Smith <rich1051414@gmail.com>
 */
public class Targetting {


	/**@params parDistance : distance of blocks to check
	 * return the entity you are looking at. null if no entity is looked at within parDistance blocks
	 * */
	@SideOnly(Side.CLIENT)
	public static EntityLivingBase rayTraceClientSide(double parDistance) {

		net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.func_71410_x();

		if(! (mc.func_175606_aa() instanceof EntityLivingBase))
			return null;

		EntityLivingBase viewEntity = (EntityLivingBase)mc.func_175606_aa();
		World worldObj = viewEntity.field_70170_p;
		Entity Return = null;

		if (viewEntity != null) {

			RayTraceResult objectMouseOver = viewEntity.func_174822_a(parDistance, 0.5F);
			Vec3d playerPosition = viewEntity.func_174824_e(1.0F);

			double farDist = parDistance;
			if (objectMouseOver != null) {
				farDist = objectMouseOver.field_72307_f.func_72438_d(playerPosition);
			}
			double closest = farDist;

			Vec3d dirVec = viewEntity.func_70040_Z();
			Vec3d lookFar = playerPosition.func_72441_c(dirVec.field_72450_a
					* parDistance, dirVec.field_72448_b * parDistance, dirVec.field_72449_c
					* parDistance);

			List<EntityLivingBase> targettedEntities = worldObj.func_72872_a(
					EntityLivingBase.class,
					viewEntity.func_174813_aQ().
					func_72314_b(dirVec.field_72450_a * parDistance,
							dirVec.field_72448_b * parDistance,
							dirVec.field_72449_c * parDistance).func_72321_a(0.1,0.1, 0.1));

			targettedEntities.remove(viewEntity);

			for (EntityLivingBase targettedEntity : targettedEntities) {
				if (targettedEntity != null) {
					double precheck = viewEntity.func_70032_d(targettedEntity);

					RayTraceResult mopElIntercept = targettedEntity.func_174813_aQ().
							func_72327_a(playerPosition, lookFar);

					if (mopElIntercept != null) {
						if (precheck < closest) {
							Return = targettedEntity;
							closest = precheck;
						}
					}
				}
			}
		}
		if ((Return != null) && (Return instanceof EntityLivingBase)) {
			return (EntityLivingBase) Return;
		}
		return null;
	}


	// Butchered from the player getMouseOver()
	private static RayTraceResult getEntityIntercept(EntityPlayer player, Vec3d start, Vec3d look, Vec3d end, RayTraceResult mop){
		double distance = end.func_72438_d(start);

		if (mop != null)
		{
			distance = mop.field_72307_f.func_72438_d(start);
		}

		Vec3d direction = new Vec3d(
				look.field_72450_a * distance,
				look.field_72448_b * distance,
				look.field_72449_c * distance);

		end = start.func_178787_e(direction);

		Vec3d hitPosition = null;
		List<Entity> list = player.field_70170_p.func_175674_a(player,
				player.func_174813_aQ()
				.func_72314_b(direction.field_72450_a, direction.field_72448_b, direction.field_72449_c)
				.func_72321_a(1.0, 1.0, 1.0), Predicates.and(EntitySelectors.field_180132_d,
						Entity::func_70067_L));

		double distanceToEntity = distance;
		Entity pointedEntity = null;
		for (Entity entity : list)
		{
			double border = entity.func_70111_Y();
			AxisAlignedBB bounds = entity.func_174813_aQ().func_72321_a(border, border, border);
			RayTraceResult intercept = bounds.func_72327_a(start, end);

			if (bounds.func_72318_a(start))
			{
				if (distanceToEntity >= 0.0D)
				{
					pointedEntity = entity;
					hitPosition = intercept == null ? start : intercept.field_72307_f;
					distanceToEntity = 0.0D;
				}
			}
			else if (intercept != null)
			{
				double interceptDistance = start.func_72438_d(intercept.field_72307_f);

				if (interceptDistance < distanceToEntity || distanceToEntity == 0.0D)
				{
					if (entity == player.func_184187_bx() && !player.canRiderInteract())
					{
						if (distanceToEntity == 0.0D)
						{
							pointedEntity = entity;
							hitPosition = intercept.field_72307_f;
						}
					}
					else
					{
						pointedEntity = entity;
						hitPosition = intercept.field_72307_f;
						distanceToEntity = interceptDistance;
					}
				}
			}
		}

		if (pointedEntity != null)
		{
			if (distanceToEntity < distance)
			{
				if (start.func_72438_d(hitPosition) < distance)
				{
					return new RayTraceResult(pointedEntity, hitPosition);
				}
			}
		}

		return mop;
	}

	/**raytrace server side*/
	public static RayTraceResult rayTraceServerSide(EntityPlayer player, float partialTicks)
	{
		Vec3d start;
		Vec3d end;

		float maxDistance = 10;

		if (partialTicks < 1)
		{
			double sx = player.field_70169_q + (player.field_70165_t - player.field_70169_q) * partialTicks;
			double sy = player.field_70167_r + (player.field_70163_u - player.field_70167_r) * partialTicks + player.func_70047_e();
			double sz = player.field_70166_s + (player.field_70161_v - player.field_70166_s) * partialTicks;
			start = new Vec3d(sx, sy, sz);
		}
		else
		{
			start = new Vec3d(player.field_70165_t, player.field_70163_u + player.func_70047_e(), player.field_70161_v);
		}

		Vec3d look = player.func_70676_i(partialTicks);
		end = start.func_72441_c(look.field_72450_a * maxDistance, look.field_72448_b * maxDistance, look.field_72449_c * maxDistance);

		RayTraceResult mop = player.field_70170_p.func_147447_a(start, end, false, true, false);

		mop = getEntityIntercept(player, start, look, end, mop);

		if (mop != null && mop.field_72307_f != null)
		{
			end = mop.field_72307_f;
		}

		return mop;
	}
}
